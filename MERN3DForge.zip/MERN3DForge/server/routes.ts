import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertModelSchema, insertRatingSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth routes
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { firebaseUid, email, displayName, photoURL } = req.body;
      
      if (!firebaseUid || !email || !displayName) {
        return res.status(400).json({ error: "Missing required fields" });
      }

      // Check if user exists
      let user = await storage.getUserByFirebaseUid(firebaseUid);
      
      if (!user) {
        // Create new user
        user = await storage.createUser({
          firebaseUid,
          email,
          displayName,
          photoURL: photoURL || null,
        });
      } else {
        // Update existing user
        user = await storage.updateUser(user.id, {
          displayName,
          photoURL: photoURL || null,
        }) || user;
      }

      res.json({ user });
    } catch (error) {
      console.error("Login error:", error);
      res.status(500).json({ error: "Failed to authenticate user" });
    }
  });

  app.get("/api/auth/me", async (req, res) => {
    try {
      const firebaseUid = req.headers.authorization?.replace("Bearer ", "");
      
      if (!firebaseUid) {
        return res.status(401).json({ error: "No authorization header" });
      }

      const user = await storage.getUserByFirebaseUid(firebaseUid);
      
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }

      res.json({ user });
    } catch (error) {
      console.error("Get user error:", error);
      res.status(500).json({ error: "Failed to get user" });
    }
  });

  // Model routes
  app.get("/api/models", async (req, res) => {
    try {
      const { userId, public: isPublic, limit = "20", offset = "0" } = req.query;
      
      if (userId && typeof userId === "string") {
        const models = await storage.getUserModels(userId);
        res.json({ models });
      } else if (isPublic === "true") {
        const models = await storage.getPublicModels(parseInt(limit as string), parseInt(offset as string));
        res.json({ models });
      } else {
        res.status(400).json({ error: "Either userId or public=true must be specified" });
      }
    } catch (error) {
      console.error("Get models error:", error);
      res.status(500).json({ error: "Failed to fetch models" });
    }
  });

  app.get("/api/models/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const model = await storage.getModel(id);
      
      if (!model) {
        return res.status(404).json({ error: "Model not found" });
      }

      res.json({ model });
    } catch (error) {
      console.error("Get model error:", error);
      res.status(500).json({ error: "Failed to fetch model" });
    }
  });

  app.post("/api/models", async (req, res) => {
    try {
      const validation = insertModelSchema.safeParse(req.body);
      
      if (!validation.success) {
        return res.status(400).json({ error: "Invalid model data", details: validation.error.errors });
      }

      const model = await storage.createModel(validation.data);
      res.status(201).json({ model });
    } catch (error) {
      console.error("Create model error:", error);
      res.status(500).json({ error: "Failed to create model" });
    }
  });

  app.patch("/api/models/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const model = await storage.updateModel(id, req.body);
      
      if (!model) {
        return res.status(404).json({ error: "Model not found" });
      }

      res.json({ model });
    } catch (error) {
      console.error("Update model error:", error);
      res.status(500).json({ error: "Failed to update model" });
    }
  });

  app.delete("/api/models/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const deleted = await storage.deleteModel(id);
      
      if (!deleted) {
        return res.status(404).json({ error: "Model not found" });
      }

      res.json({ success: true });
    } catch (error) {
      console.error("Delete model error:", error);
      res.status(500).json({ error: "Failed to delete model" });
    }
  });

  app.post("/api/models/:id/download", async (req, res) => {
    try {
      const { id } = req.params;
      await storage.incrementModelDownloads(id);
      res.json({ success: true });
    } catch (error) {
      console.error("Download increment error:", error);
      res.status(500).json({ error: "Failed to track download" });
    }
  });

  app.post("/api/models/:id/like", async (req, res) => {
    try {
      const { id } = req.params;
      await storage.incrementModelLikes(id);
      res.json({ success: true });
    } catch (error) {
      console.error("Like increment error:", error);
      res.status(500).json({ error: "Failed to track like" });
    }
  });

  // Rating routes
  app.get("/api/models/:id/ratings", async (req, res) => {
    try {
      const { id } = req.params;
      const ratings = await storage.getModelRatings(id);
      res.json({ ratings });
    } catch (error) {
      console.error("Get ratings error:", error);
      res.status(500).json({ error: "Failed to fetch ratings" });
    }
  });

  app.post("/api/models/:id/ratings", async (req, res) => {
    try {
      const { id: modelId } = req.params;
      const validation = insertRatingSchema.safeParse({ ...req.body, modelId });
      
      if (!validation.success) {
        return res.status(400).json({ error: "Invalid rating data", details: validation.error.errors });
      }

      const rating = await storage.createRating(validation.data);
      res.status(201).json({ rating });
    } catch (error) {
      console.error("Create rating error:", error);
      res.status(500).json({ error: "Failed to create rating" });
    }
  });

  // Text-to-3D generation endpoint (placeholder for future AI integration)
  app.post("/api/generate/text-to-3d", async (req, res) => {
    try {
      const { prompt, userId, settings } = req.body;
      
      if (!prompt || !userId) {
        return res.status(400).json({ error: "Prompt and userId are required" });
      }

      // Create model in processing state
      const model = await storage.createModel({
        userId,
        name: `Text-to-3D: ${prompt.substring(0, 50)}...`,
        description: prompt,
        type: "text-to-3d",
        prompt,
        status: "processing",
        settings,
        isPublic: false,
      });

      // TODO: Integrate with Point-E or Shap-E for actual 3D generation
      // For now, simulate processing time and complete the model
      setTimeout(async () => {
        await storage.updateModel(model.id, {
          status: "completed",
          modelUrl: "/api/models/placeholder.glb", // Placeholder URL
          thumbnailUrl: "/api/models/placeholder-thumb.jpg",
        });
      }, 5000);

      res.json({ model, message: "Generation started" });
    } catch (error) {
      console.error("Text-to-3D generation error:", error);
      res.status(500).json({ error: "Failed to start generation" });
    }
  });

  // Image-to-3D generation endpoint (placeholder for future implementation)
  app.post("/api/generate/image-to-3d", async (req, res) => {
    try {
      const { userId, settings } = req.body;
      
      if (!userId) {
        return res.status(400).json({ error: "UserId is required" });
      }

      // Create model in processing state
      const model = await storage.createModel({
        userId,
        name: "Image-to-3D Model",
        description: "Generated from uploaded images",
        type: "image-to-3d",
        status: "processing",
        settings,
        isPublic: false,
      });

      // TODO: Integrate with COLMAP or Meshroom for photogrammetry
      // For now, just create a placeholder
      setTimeout(async () => {
        await storage.updateModel(model.id, {
          status: "completed",
          modelUrl: "/api/models/placeholder.glb",
          thumbnailUrl: "/api/models/placeholder-thumb.jpg",
        });
      }, 10000);

      res.json({ model, message: "Processing started" });
    } catch (error) {
      console.error("Image-to-3D generation error:", error);
      res.status(500).json({ error: "Failed to start processing" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
