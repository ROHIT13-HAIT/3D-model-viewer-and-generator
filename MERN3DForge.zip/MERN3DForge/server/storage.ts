import { type User, type InsertUser, type Model, type InsertModel, type ModelRating, type InsertRating } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByFirebaseUid(firebaseUid: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, updates: Partial<User>): Promise<User | undefined>;

  // Model operations
  getModel(id: string): Promise<Model | undefined>;
  getUserModels(userId: string): Promise<Model[]>;
  getPublicModels(limit?: number, offset?: number): Promise<Model[]>;
  createModel(model: InsertModel): Promise<Model>;
  updateModel(id: string, updates: Partial<Model>): Promise<Model | undefined>;
  deleteModel(id: string): Promise<boolean>;
  incrementModelDownloads(id: string): Promise<void>;
  incrementModelLikes(id: string): Promise<void>;

  // Rating operations
  getModelRatings(modelId: string): Promise<ModelRating[]>;
  getUserRating(modelId: string, userId: string): Promise<ModelRating | undefined>;
  createRating(rating: InsertRating): Promise<ModelRating>;
  updateRating(id: string, updates: Partial<ModelRating>): Promise<ModelRating | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private models: Map<string, Model>;
  private ratings: Map<string, ModelRating>;

  constructor() {
    this.users = new Map();
    this.models = new Map();
    this.ratings = new Map();
  }

  // User operations
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async getUserByFirebaseUid(firebaseUid: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.firebaseUid === firebaseUid);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = {
      ...insertUser,
      id,
      photoURL: insertUser.photoURL || null,
      createdAt: new Date(),
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: string, updates: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...updates };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Model operations
  async getModel(id: string): Promise<Model | undefined> {
    return this.models.get(id);
  }

  async getUserModels(userId: string): Promise<Model[]> {
    return Array.from(this.models.values())
      .filter(model => model.userId === userId)
      .sort((a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime());
  }

  async getPublicModels(limit = 20, offset = 0): Promise<Model[]> {
    const publicModels = Array.from(this.models.values())
      .filter(model => model.isPublic && model.status === 'completed')
      .sort((a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime());
    
    return publicModels.slice(offset, offset + limit);
  }

  async createModel(insertModel: InsertModel): Promise<Model> {
    const id = randomUUID();
    const model: Model = {
      ...insertModel,
      id,
      description: insertModel.description || null,
      prompt: insertModel.prompt || null,
      modelUrl: insertModel.modelUrl || null,
      thumbnailUrl: insertModel.thumbnailUrl || null,
      settings: insertModel.settings || null,
      status: insertModel.status || "processing",
      isPublic: insertModel.isPublic || false,
      downloads: 0,
      likes: 0,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.models.set(id, model);
    return model;
  }

  async updateModel(id: string, updates: Partial<Model>): Promise<Model | undefined> {
    const model = this.models.get(id);
    if (!model) return undefined;
    
    const updatedModel = { ...model, ...updates, updatedAt: new Date() };
    this.models.set(id, updatedModel);
    return updatedModel;
  }

  async deleteModel(id: string): Promise<boolean> {
    return this.models.delete(id);
  }

  async incrementModelDownloads(id: string): Promise<void> {
    const model = this.models.get(id);
    if (model) {
      model.downloads = (model.downloads || 0) + 1;
      this.models.set(id, model);
    }
  }

  async incrementModelLikes(id: string): Promise<void> {
    const model = this.models.get(id);
    if (model) {
      model.likes = (model.likes || 0) + 1;
      this.models.set(id, model);
    }
  }

  // Rating operations
  async getModelRatings(modelId: string): Promise<ModelRating[]> {
    return Array.from(this.ratings.values())
      .filter(rating => rating.modelId === modelId)
      .sort((a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime());
  }

  async getUserRating(modelId: string, userId: string): Promise<ModelRating | undefined> {
    return Array.from(this.ratings.values())
      .find(rating => rating.modelId === modelId && rating.userId === userId);
  }

  async createRating(insertRating: InsertRating): Promise<ModelRating> {
    const id = randomUUID();
    const rating: ModelRating = {
      ...insertRating,
      id,
      comment: insertRating.comment || null,
      createdAt: new Date(),
    };
    this.ratings.set(id, rating);
    return rating;
  }

  async updateRating(id: string, updates: Partial<ModelRating>): Promise<ModelRating | undefined> {
    const rating = this.ratings.get(id);
    if (!rating) return undefined;
    
    const updatedRating = { ...rating, ...updates };
    this.ratings.set(id, updatedRating);
    return updatedRating;
  }
}

export const storage = new MemStorage();
