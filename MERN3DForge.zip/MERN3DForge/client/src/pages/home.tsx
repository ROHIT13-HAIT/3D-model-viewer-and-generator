import { motion } from "framer-motion";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ModelViewer } from "@/components/three/model-viewer";
import { 
  Sparkles, 
  Image, 
  Download, 
  Users, 
  Zap, 
  Layers3,
  ArrowRight 
} from "lucide-react";

export default function Home() {
  const features = [
    {
      icon: <Sparkles className="h-6 w-6" />,
      title: "Text to 3D",
      description: "Describe your vision and watch it come to life in stunning 3D models",
    },
    {
      icon: <Image className="h-6 w-6" />,
      title: "Image to 3D",
      description: "Upload photos and convert them to interactive 3D models using photogrammetry",
    },
    {
      icon: <Layers3 className="h-6 w-6" />,
      title: "Advanced Editor",
      description: "Fine-tune your models with professional editing tools and lighting controls",
    },
    {
      icon: <Download className="h-6 w-6" />,
      title: "Export Anywhere",
      description: "Download in multiple formats (GLB, GLTF, OBJ) or generate embed codes",
    },
    {
      icon: <Users className="h-6 w-6" />,
      title: "Community Gallery",
      description: "Share your creations and discover inspiring models from other creators",
    },
    {
      icon: <Zap className="h-6 w-6" />,
      title: "Lightning Fast",
      description: "Generate high-quality 3D models in seconds with our optimized AI pipeline",
    },
  ];

  const stats = [
    { label: "Models Generated", value: "50K+" },
    { label: "Active Users", value: "10K+" },
    { label: "Uptime", value: "99.9%" },
  ];

  return (
    <div className="pt-16">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        {/* Animated Background */}
        <div className="absolute inset-0 -z-10">
          <div className="absolute top-20 left-10 w-32 h-32 bg-primary/20 rounded-full animate-pulse" />
          <div className="absolute top-40 right-20 w-24 h-24 bg-accent/20 rounded-lg animate-pulse" 
               style={{ animationDelay: "-2s" }} />
          <div className="absolute bottom-32 left-1/4 w-16 h-16 bg-primary/30 rounded-full animate-pulse" 
               style={{ animationDelay: "-4s" }} />
          
          {/* Grid pattern */}
          <div className="absolute inset-0 bg-[linear-gradient(rgba(139,92,246,0.1)_1px,transparent_1px),linear-gradient(90deg,rgba(139,92,246,0.1)_1px,transparent_1px)] bg-[size:50px_50px]" />
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Hero Content */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="space-y-8"
            >
              <div className="space-y-4">
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.4, delay: 0.2 }}
                  className="inline-flex items-center px-3 py-1 rounded-full bg-primary/10 border border-primary/20 text-primary text-sm font-medium"
                >
                  ✨ AI-Powered 3D Generation
                </motion.div>
                
                <motion.h1
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.3 }}
                  className="text-4xl md:text-6xl font-bold leading-tight"
                >
                  Create Stunning
                  <span className="bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent">
                    {" "}3D Models
                  </span>
                  <br />
                  from Text & Images
                </motion.h1>
                
                <motion.p
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.4 }}
                  className="text-xl text-muted-foreground max-w-xl"
                >
                  Transform your creative ideas into professional 3D models using cutting-edge AI. 
                  Generate from text prompts or convert images to interactive 3D content.
                </motion.p>
              </div>

              {/* CTA Buttons */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.5 }}
                className="flex flex-col sm:flex-row gap-4"
              >
                <Link href="/text-to-3d">
                  <Button size="lg" className="group" data-testid="start-creating">
                    Start Creating
                    <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                  </Button>
                </Link>
                <Link href="/gallery">
                  <Button variant="outline" size="lg" data-testid="view-gallery">
                    View Gallery
                  </Button>
                </Link>
              </motion.div>

              {/* Stats */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.6 }}
                className="flex items-center space-x-8 pt-8 border-t border-border"
              >
                {stats.map((stat, index) => (
                  <div key={index}>
                    <div className="text-2xl font-bold text-primary">{stat.value}</div>
                    <div className="text-sm text-muted-foreground">{stat.label}</div>
                  </div>
                ))}
              </motion.div>
            </motion.div>

            {/* 3D Preview Area */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="relative"
            >
              <Card className="backdrop-blur-sm bg-card/50 border-border/50">
                <CardContent className="p-8">
                  <div className="aspect-square rounded-xl overflow-hidden bg-gradient-to-br from-secondary to-muted relative">
                    <ModelViewer autoRotate className="w-full h-full" />
                    
                    {/* Model Controls */}
                    <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-2">
                      <Button variant="secondary" size="sm" data-testid="rotate-model">
                        Rotate
                      </Button>
                      <Button variant="secondary" size="sm" data-testid="zoom-model">
                        Zoom
                      </Button>
                      <Button variant="secondary" size="sm" data-testid="reset-view">
                        Reset
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Floating elements */}
              <div className="absolute -top-4 -right-4 w-16 h-16 bg-primary/20 rounded-full animate-pulse" />
              <div className="absolute -bottom-4 -left-4 w-12 h-12 bg-accent/20 rounded-lg animate-pulse" 
                   style={{ animationDelay: "-3s" }} />
            </motion.div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 border-t border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Everything you need to create
              <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                {" "}amazing 3D models
              </span>
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Powerful AI-driven tools combined with intuitive design to bring your creative vision to life
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
              >
                <Card className="backdrop-blur-sm bg-card/50 border-border/50 hover:bg-card/70 transition-colors duration-300 h-full">
                  <CardHeader>
                    <div className="w-12 h-12 bg-gradient-to-br from-primary to-accent rounded-lg flex items-center justify-center text-primary-foreground mb-4">
                      {feature.icon}
                    </div>
                    <CardTitle className="text-xl">{feature.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <CardDescription className="text-muted-foreground mb-4">
                      {feature.description}
                    </CardDescription>
                    <div className="flex items-center text-primary text-sm font-medium">
                      Try it now
                      <ArrowRight className="h-4 w-4 ml-1" />
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
