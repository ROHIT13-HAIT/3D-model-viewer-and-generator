import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import {
  Search,
  Download,
  Eye,
  Heart,
  Star,
  Sparkles,
  Image as ImageIcon,
  Users,
  TrendingUp,
} from "lucide-react";

interface GalleryModel {
  id: string;
  name: string;
  description: string;
  type: 'text-to-3d' | 'image-to-3d';
  userId: string;
  downloads: number;
  likes: number;
  createdAt: string;
  thumbnailUrl?: string;
}

export default function Gallery() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [searchQuery, setSearchQuery] = useState("");
  const [sortBy, setSortBy] = useState("recent");
  const [filterType, setFilterType] = useState("all");

  const { data: modelsData, isLoading } = useQuery({
    queryKey: ['/api/models', { public: true, limit: 20, offset: 0 }],
  });

  const downloadMutation = useMutation({
    mutationFn: async (modelId: string) => {
      await apiRequest('POST', `/api/models/${modelId}/download`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/models'] });
      toast({
        title: "Download started",
        description: "Your model download has begun.",
      });
    },
  });

  const likeMutation = useMutation({
    mutationFn: async (modelId: string) => {
      await apiRequest('POST', `/api/models/${modelId}/like`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/models'] });
      toast({
        title: "Model liked!",
        description: "Thanks for your feedback.",
      });
    },
  });

  const models: GalleryModel[] = (modelsData as any)?.models || [];
  
  // Filter and sort models
  const filteredModels = models
    .filter(model => {
      const matchesSearch = model.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           model.description?.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesType = filterType === "all" || model.type === filterType;
      return matchesSearch && matchesType;
    })
    .sort((a, b) => {
      switch (sortBy) {
        case "popular":
          return (b.downloads + b.likes) - (a.downloads + a.likes);
        case "downloads":
          return b.downloads - a.downloads;
        case "likes":
          return b.likes - a.likes;
        case "recent":
        default:
          return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      }
    });

  const mockModels = [
    {
      id: "1",
      name: "Cute Dragon",
      description: "A cute cartoon dragon with wings, sitting on a treasure chest",
      type: "text-to-3d" as const,
      userId: "user1",
      downloads: 1240,
      likes: 89,
      createdAt: "2024-01-15T10:30:00Z",
      rating: 4.8,
      creator: "@artcreator99"
    },
    {
      id: "2",
      name: "Spaceship Design",
      description: "Futuristic spacecraft with sleek metallic surfaces and glowing blue engines",
      type: "text-to-3d" as const,
      userId: "user2",
      downloads: 892,
      likes: 67,
      createdAt: "2024-01-14T14:20:00Z",
      rating: 4.6,
      creator: "@spacefan_3d"
    },
    {
      id: "3",
      name: "Modern Chair",
      description: "Contemporary furniture design with clean lines and premium materials",
      type: "image-to-3d" as const,
      userId: "user3",
      downloads: 634,
      likes: 45,
      createdAt: "2024-01-13T09:15:00Z",
      rating: 4.5,
      creator: "@designpro"
    },
    {
      id: "4",
      name: "Abstract Sculpture",
      description: "Modern abstract art piece with flowing organic forms",
      type: "text-to-3d" as const,
      userId: "user4",
      downloads: 423,
      likes: 31,
      createdAt: "2024-01-12T16:45:00Z",
      rating: 3.9,
      creator: "@sculptor_ai"
    },
  ];

  // Use mock data if no real models are loaded
  const displayModels = filteredModels.length > 0 ? filteredModels : mockModels;

  return (
    <div className="pt-16 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h1 className="text-4xl font-bold mb-4">
            Community <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">Gallery</span>
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Discover amazing 3D models created by our community. Get inspired and share your own creations.
          </p>
        </motion.div>

        {/* Filters & Search */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="flex flex-col md:flex-row gap-4 mb-8"
        >
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
              <Input
                type="text"
                placeholder="Search models..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
                data-testid="search-input"
              />
            </div>
          </div>
          <div className="flex gap-2">
            <Select value={filterType} onValueChange={setFilterType}>
              <SelectTrigger className="w-[160px]" data-testid="type-filter">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="text-to-3d">Text-to-3D</SelectItem>
                <SelectItem value="image-to-3d">Image-to-3D</SelectItem>
              </SelectContent>
            </Select>
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-[140px]" data-testid="sort-filter">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="recent">Recent</SelectItem>
                <SelectItem value="popular">Most Popular</SelectItem>
                <SelectItem value="downloads">Most Downloaded</SelectItem>
                <SelectItem value="likes">Most Liked</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </motion.div>

        {/* Gallery Grid */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mb-8"
        >
          {isLoading ? (
            Array.from({ length: 8 }).map((_, index) => (
              <Card key={index} className="overflow-hidden">
                <Skeleton className="aspect-square w-full" />
                <div className="p-4 space-y-2">
                  <Skeleton className="h-4 w-3/4" />
                  <Skeleton className="h-3 w-1/2" />
                  <div className="flex items-center justify-between">
                    <Skeleton className="h-3 w-16" />
                    <Skeleton className="h-3 w-12" />
                  </div>
                </div>
              </Card>
            ))
          ) : (
            displayModels.map((model, index) => (
              <motion.div
                key={model.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, delay: index * 0.05 }}
              >
                <Card className="overflow-hidden hover:shadow-lg transition-all duration-300 group">
                  {/* Model Preview */}
                  <div className="aspect-square bg-gradient-to-br from-primary/20 to-accent/20 relative overflow-hidden">
                    <div className="w-full h-full bg-gradient-to-br from-primary/30 to-accent/30 flex items-center justify-center">
                      <div className="w-24 h-24 bg-gradient-to-br from-primary/40 to-accent/40 rounded-lg group-hover:scale-110 transition-transform duration-300" />
                    </div>
                    
                    {/* Hover Actions */}
                    <div className="absolute inset-0 bg-background/80 backdrop-blur-sm opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                      <div className="flex space-x-2">
                        <Button size="sm" data-testid={`preview-${model.id}`}>
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => downloadMutation.mutate(model.id)}
                          data-testid={`download-${model.id}`}
                        >
                          <Download className="h-4 w-4" />
                        </Button>
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => likeMutation.mutate(model.id)}
                          data-testid={`like-${model.id}`}
                        >
                          <Heart className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>

                  {/* Model Info */}
                  <CardContent className="p-4">
                    <h3 className="font-semibold truncate mb-1">{model.name}</h3>
                    <p className="text-sm text-muted-foreground mb-3">
                      by {(model as any).creator || "Anonymous"}
                    </p>
                    
                    {/* Stats & Type */}
                    <div className="flex items-center justify-between text-sm mb-3">
                      <div className="flex items-center space-x-4">
                        <div className="flex items-center space-x-1">
                          {(model as any).rating && (
                            <>
                              <div className="flex text-yellow-400">
                                {Array.from({ length: 5 }).map((_, i) => (
                                  <Star 
                                    key={i} 
                                    className={`w-3 h-3 ${i < Math.floor((model as any).rating) ? 'fill-current' : ''}`} 
                                  />
                                ))}
                              </div>
                              <span className="text-muted-foreground ml-1">{(model as any).rating}</span>
                            </>
                          )}
                        </div>
                        <div className="flex items-center space-x-1">
                          <Download className="h-3 w-3 text-muted-foreground" />
                          <span className="text-muted-foreground">{model.downloads}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Heart className="h-3 w-3 text-muted-foreground" />
                          <span className="text-muted-foreground">{model.likes}</span>
                        </div>
                      </div>
                      <Badge variant={model.type === 'text-to-3d' ? 'default' : 'secondary'}>
                        {model.type === 'text-to-3d' ? (
                          <><Sparkles className="w-3 h-3 mr-1" />Text-to-3D</>
                        ) : (
                          <><ImageIcon className="w-3 h-3 mr-1" />Image-to-3D</>
                        )}
                      </Badge>
                    </div>
                    
                    <div className="text-xs text-muted-foreground">
                      {new Date(model.createdAt).toLocaleDateString()}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))
          )}
        </motion.div>

        {/* Load More Button */}
        {!isLoading && displayModels.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="text-center"
          >
            <Button variant="outline" size="lg" data-testid="load-more">
              Load More Models
            </Button>
          </motion.div>
        )}

        {/* Empty State */}
        {!isLoading && displayModels.length === 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-center py-16"
          >
            <Users className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-xl font-semibold mb-2">No models found</h3>
            <p className="text-muted-foreground mb-6">
              {searchQuery || filterType !== "all" 
                ? "Try adjusting your search or filters"
                : "Be the first to share a model with the community"
              }
            </p>
            {!searchQuery && filterType === "all" && (
              <Button>
                <Sparkles className="mr-2 h-4 w-4" />
                Create Your First Model
              </Button>
            )}
          </motion.div>
        )}
      </div>
    </div>
  );
}
