import { useEffect, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import {
  Download,
  Eye,
  Share2,
  Plus,
  Layers3,
  TrendingUp,
  Database,
  MoreVertical,
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface Model {
  id: string;
  name: string;
  description: string;
  type: 'text-to-3d' | 'image-to-3d';
  status: 'processing' | 'completed' | 'failed';
  createdAt: string;
  downloads: number;
  likes: number;
}

export default function Dashboard() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: modelsData, isLoading } = useQuery({
    queryKey: ['/api/models', { userId: user?.id }],
    enabled: !!user?.id,
  });

  const downloadMutation = useMutation({
    mutationFn: async (modelId: string) => {
      await apiRequest('POST', `/api/models/${modelId}/download`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/models'] });
      toast({
        title: "Download started",
        description: "Your model download has begun.",
      });
    },
  });

  const models: Model[] = (modelsData as any)?.models || [];
  
  const stats = {
    totalModels: models.length,
    monthlyModels: models.filter(m => {
      const monthAgo = new Date();
      monthAgo.setMonth(monthAgo.getMonth() - 1);
      return new Date(m.createdAt) > monthAgo;
    }).length,
    downloads: models.reduce((sum, m) => sum + m.downloads, 0),
    storageUsed: `${(models.length * 2.4).toFixed(1)} MB`,
  };

  const recentModels = models.slice(0, 5);

  if (!user) {
    return (
      <div className="pt-16 min-h-screen flex items-center justify-center">
        <Card className="w-full max-w-md mx-4">
          <CardContent className="pt-6 text-center">
            <h1 className="text-2xl font-bold mb-4">Sign in required</h1>
            <p className="text-muted-foreground mb-4">
              Please sign in to access your dashboard.
            </p>
            <Link href="/auth">
              <Button>Sign In</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="pt-16 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Dashboard Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="flex items-center justify-between mb-8"
        >
          <div>
            <h1 className="text-3xl font-bold">
              Welcome back, <span className="text-primary">{user.displayName}!</span>
            </h1>
            <p className="text-muted-foreground">
              Manage your 3D models and track your creative progress
            </p>
          </div>
          <Link href="/text-to-3d">
            <Button className="gap-2" data-testid="create-new-model">
              <Plus className="h-5 w-5" />
              Create New Model
            </Button>
          </Link>
        </motion.div>

        {/* Stats Cards */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="grid md:grid-cols-4 gap-6 mb-8"
        >
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total Models</p>
                  <p className="text-2xl font-bold text-primary" data-testid="total-models">
                    {stats.totalModels}
                  </p>
                </div>
                <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center">
                  <Layers3 className="h-6 w-6 text-primary" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">This Month</p>
                  <p className="text-2xl font-bold text-accent" data-testid="monthly-models">
                    {stats.monthlyModels}
                  </p>
                </div>
                <div className="w-12 h-12 bg-accent/20 rounded-lg flex items-center justify-center">
                  <TrendingUp className="h-6 w-6 text-accent" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Downloads</p>
                  <p className="text-2xl font-bold text-primary" data-testid="total-downloads">
                    {stats.downloads}
                  </p>
                </div>
                <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center">
                  <Download className="h-6 w-6 text-primary" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Storage Used</p>
                  <p className="text-2xl font-bold text-accent" data-testid="storage-used">
                    {stats.storageUsed}
                  </p>
                </div>
                <div className="w-12 h-12 bg-accent/20 rounded-lg flex items-center justify-center">
                  <Database className="h-6 w-6 text-accent" />
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Recent Models & Quick Actions */}
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Recent Models */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="lg:col-span-2"
          >
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold">Recent Models</h2>
              <Link href="/models">
                <Button variant="outline" size="sm">View All</Button>
              </Link>
            </div>

            <div className="space-y-4">
              {isLoading ? (
                Array.from({ length: 3 }).map((_, i) => (
                  <Card key={i}>
                    <CardContent className="p-4">
                      <div className="flex items-center space-x-4">
                        <Skeleton className="w-16 h-16 rounded-lg" />
                        <div className="flex-1">
                          <Skeleton className="h-4 w-32 mb-2" />
                          <Skeleton className="h-3 w-48" />
                        </div>
                        <div className="flex space-x-2">
                          <Skeleton className="h-8 w-16" />
                          <Skeleton className="h-8 w-8" />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))
              ) : recentModels.length === 0 ? (
                <Card>
                  <CardContent className="p-8 text-center">
                    <Layers3 className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
                    <h3 className="text-lg font-semibold mb-2">No models yet</h3>
                    <p className="text-muted-foreground mb-4">
                      Create your first 3D model to get started
                    </p>
                    <Link href="/text-to-3d">
                      <Button>Create Model</Button>
                    </Link>
                  </CardContent>
                </Card>
              ) : (
                recentModels.map((model, index) => (
                  <motion.div
                    key={model.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.4, delay: index * 0.1 }}
                  >
                    <Card className="hover:bg-muted/50 transition-colors">
                      <CardContent className="p-4">
                        <div className="flex items-center space-x-4">
                          {/* Model Thumbnail */}
                          <div className="w-16 h-16 bg-gradient-to-br from-primary/30 to-accent/30 rounded-lg flex-shrink-0">
                            {/* 3D model thumbnail would be rendered here */}
                          </div>
                          
                          {/* Model Info */}
                          <div className="flex-1 min-w-0">
                            <h3 className="font-medium truncate">{model.name}</h3>
                            <div className="flex items-center gap-2 mt-1">
                              <Badge variant={model.type === 'text-to-3d' ? 'default' : 'secondary'}>
                                {model.type === 'text-to-3d' ? 'Text-to-3D' : 'Image-to-3D'}
                              </Badge>
                              <Badge variant={
                                model.status === 'completed' ? 'default' : 
                                model.status === 'processing' ? 'secondary' : 'destructive'
                              }>
                                {model.status}
                              </Badge>
                            </div>
                            <p className="text-sm text-muted-foreground mt-1">
                              Created {new Date(model.createdAt).toLocaleDateString()}
                            </p>
                          </div>

                          {/* Actions */}
                          <div className="flex items-center space-x-2 flex-shrink-0">
                            <Button variant="ghost" size="sm" data-testid={`preview-${model.id}`}>
                              <Eye className="h-4 w-4" />
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="sm"
                              onClick={() => downloadMutation.mutate(model.id)}
                              disabled={model.status !== 'completed'}
                              data-testid={`download-${model.id}`}
                            >
                              <Download className="h-4 w-4" />
                            </Button>
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="sm">
                                  <MoreVertical className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuItem>
                                  <Share2 className="mr-2 h-4 w-4" />
                                  Share
                                </DropdownMenuItem>
                                <DropdownMenuItem>
                                  <Eye className="mr-2 h-4 w-4" />
                                  View Details
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))
              )}
            </div>
          </motion.div>

          {/* Quick Actions & Recent Activity */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="space-y-6"
          >
            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Link href="/text-to-3d">
                  <Button className="w-full justify-start gap-3" data-testid="quick-text-to-3d">
                    <Layers3 className="h-5 w-5" />
                    Text to 3D
                  </Button>
                </Link>
                <Link href="/image-to-3d">
                  <Button variant="secondary" className="w-full justify-start gap-3" data-testid="quick-image-to-3d">
                    <Plus className="h-5 w-5" />
                    Image to 3D
                  </Button>
                </Link>
                <Link href="/gallery">
                  <Button variant="secondary" className="w-full justify-start gap-3" data-testid="quick-gallery">
                    <Eye className="h-5 w-5" />
                    Browse Gallery
                  </Button>
                </Link>
              </CardContent>
            </Card>

            {/* Recent Activity */}
            <Card>
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {recentModels.slice(0, 3).map((model) => (
                  <div key={model.id} className="flex items-start space-x-3">
                    <div className="w-8 h-8 bg-primary/20 rounded-full flex items-center justify-center flex-shrink-0">
                      <Plus className="h-4 w-4 text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm text-foreground">Created "{model.name}"</p>
                      <p className="text-xs text-muted-foreground">
                        {new Date(model.createdAt).toLocaleString()}
                      </p>
                    </div>
                  </div>
                ))}
                {recentModels.length === 0 && (
                  <p className="text-sm text-muted-foreground text-center py-4">
                    No recent activity
                  </p>
                )}
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
