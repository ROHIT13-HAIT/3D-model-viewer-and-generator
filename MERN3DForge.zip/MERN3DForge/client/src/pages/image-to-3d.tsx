import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import {
  Upload,
  X,
  ImageIcon,
  Zap,
  CheckCircle,
  Clock,
  AlertCircle,
  Camera,
} from "lucide-react";

export default function ImageTo3D() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [quality, setQuality] = useState("high");
  const [outputFormat, setOutputFormat] = useState("glb");
  const [generateTextures, setGenerateTextures] = useState(true);
  const [autoCleanup, setAutoCleanup] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [processingProgress, setProcessingProgress] = useState(0);

  const processMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest('POST', '/api/generate/image-to-3d', data);
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/models'] });
      toast({
        title: "Processing started",
        description: "Your images are being processed into a 3D model. This may take 15-30 minutes.",
      });
      
      // Simulate progress updates
      const progressInterval = setInterval(() => {
        setProcessingProgress(prev => {
          const newProgress = Math.min(prev + Math.random() * 10, 95);
          return newProgress;
        });
      }, 2000);

      // Complete processing after 10 seconds (simulation)
      setTimeout(() => {
        clearInterval(progressInterval);
        setProcessingProgress(100);
        setIsProcessing(false);
        toast({
          title: "Model generated successfully!",
          description: "Your 3D model is ready for preview and download.",
        });
      }, 10000);
    },
    onError: (error) => {
      setIsProcessing(false);
      setProcessingProgress(0);
      toast({
        title: "Processing failed",
        description: "There was an error processing your images. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files || []);
    const validFiles = files.filter(file => {
      const isValidType = file.type.startsWith('image/');
      const isValidSize = file.size <= 10 * 1024 * 1024; // 10MB limit
      return isValidType && isValidSize;
    });

    if (validFiles.length !== files.length) {
      toast({
        title: "Some files were excluded",
        description: "Only image files under 10MB are accepted.",
        variant: "destructive",
      });
    }

    setSelectedFiles(prev => [...prev, ...validFiles].slice(0, 20)); // Max 20 images
  };

  const removeFile = (index: number) => {
    setSelectedFiles(prev => prev.filter((_, i) => i !== index));
  };

  const handleProcess = async () => {
    if (!user) {
      toast({
        title: "Sign in required",
        description: "Please sign in to process images into 3D models.",
        variant: "destructive",
      });
      return;
    }

    if (selectedFiles.length < 3) {
      toast({
        title: "More images needed",
        description: "Please upload at least 3 images for best results.",
        variant: "destructive",
      });
      return;
    }

    setIsProcessing(true);
    setProcessingProgress(0);

    processMutation.mutate({
      userId: user.id,
      settings: {
        quality,
        outputFormat,
        generateTextures,
        autoCleanup,
        imageCount: selectedFiles.length,
      },
    });
  };

  const photographyTips = [
    "Take 10-20 photos from different angles around your object",
    "Ensure good lighting and avoid shadows",
    "Keep the object in focus and avoid blurry images",
    "Use a plain background for better results",
    "Overlap each photo by 60-80% for better reconstruction",
    "Capture all sides of the object including top and bottom",
  ];

  return (
    <div className="pt-16 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h1 className="text-4xl font-bold mb-4">
            Image to <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">3D Model</span>
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Upload multiple images of your object to generate a detailed 3D model using photogrammetry
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Upload Section */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="space-y-6"
          >
            {/* File Upload Area */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Upload className="h-5 w-5" />
                  Upload Images
                </CardTitle>
                <CardDescription>
                  Upload 3-20 images of your object from different angles
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="border-2 border-dashed border-border rounded-xl p-8 text-center hover:border-primary/50 transition-colors">
                  <div className="space-y-4">
                    <div className="w-16 h-16 bg-gradient-to-br from-primary/20 to-accent/20 rounded-xl mx-auto flex items-center justify-center">
                      <Camera className="h-8 w-8 text-primary" />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold mb-2">Upload Images</h3>
                      <p className="text-muted-foreground mb-4">
                        Drag and drop your images here, or click to browse
                      </p>
                      <input
                        type="file"
                        multiple
                        accept="image/*"
                        onChange={handleFileSelect}
                        className="hidden"
                        id="file-upload"
                        data-testid="file-input"
                      />
                      <label htmlFor="file-upload">
                        <Button asChild className="cursor-pointer" data-testid="upload-button">
                          <span>Choose Files</span>
                        </Button>
                      </label>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Supported: JPG, PNG, WebP • Max 20 images • 10MB per file
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Uploaded Images Grid */}
            {selectedFiles.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>Uploaded Images ({selectedFiles.length})</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-3 gap-3">
                    {selectedFiles.map((file, index) => (
                      <div key={index} className="relative group">
                        <img
                          src={URL.createObjectURL(file)}
                          alt={`Upload ${index + 1}`}
                          className="w-full h-20 object-cover rounded-lg"
                        />
                        <Button
                          variant="destructive"
                          size="sm"
                          className="absolute -top-2 -right-2 w-6 h-6 rounded-full p-0 opacity-0 group-hover:opacity-100 transition-opacity"
                          onClick={() => removeFile(index)}
                          data-testid={`remove-image-${index}`}
                        >
                          <X className="h-3 w-3" />
                        </Button>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Processing Settings */}
            <Card>
              <CardHeader>
                <CardTitle>Processing Settings</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="quality">Quality</Label>
                    <Select value={quality} onValueChange={setQuality}>
                      <SelectTrigger id="quality" data-testid="quality-select">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="fast">Fast (10-15 min)</SelectItem>
                        <SelectItem value="standard">Standard (15-25 min)</SelectItem>
                        <SelectItem value="high">High Quality (25-45 min)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="format">Output Format</Label>
                    <Select value={outputFormat} onValueChange={setOutputFormat}>
                      <SelectTrigger id="format" data-testid="format-select">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="glb">GLB (Recommended)</SelectItem>
                        <SelectItem value="gltf">GLTF</SelectItem>
                        <SelectItem value="obj">OBJ</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="space-y-3">
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="generate-textures"
                      checked={generateTextures}
                      onCheckedChange={(checked) => setGenerateTextures(checked === true)}
                      data-testid="generate-textures"
                    />
                    <Label htmlFor="generate-textures" className="text-sm">
                      Generate texture maps
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="auto-cleanup"
                      checked={autoCleanup}
                      onCheckedChange={(checked) => setAutoCleanup(checked === true)}
                      data-testid="auto-cleanup"
                    />
                    <Label htmlFor="auto-cleanup" className="text-sm">
                      Auto-cleanup mesh geometry
                    </Label>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Process Button */}
            <Button
              onClick={handleProcess}
              disabled={isProcessing || selectedFiles.length < 3}
              className="w-full py-6 text-lg gap-2"
              data-testid="process-button"
            >
              {isProcessing ? (
                <>
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-primary-foreground" />
                  Processing Images...
                </>
              ) : (
                <>
                  <Zap className="h-5 w-5" />
                  Generate 3D Model from Images
                </>
              )}
            </Button>

            {/* Processing Status */}
            {isProcessing && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                transition={{ duration: 0.3 }}
              >
                <Card>
                  <CardContent className="pt-6">
                    <div className="space-y-4">
                      <div className="flex items-center justify-between text-sm">
                        <span>Processing Progress</span>
                        <span>{Math.round(processingProgress)}%</span>
                      </div>
                      <Progress value={processingProgress} className="w-full" />
                      <div className="text-xs text-muted-foreground space-y-1">
                        <div className="flex items-center gap-2">
                          <CheckCircle className="w-3 h-3 text-green-500" />
                          <span>Images uploaded and validated</span>
                        </div>
                        <div className="flex items-center gap-2">
                          {processingProgress > 30 ? (
                            <CheckCircle className="w-3 h-3 text-green-500" />
                          ) : (
                            <div className="w-3 h-3 border border-primary border-t-transparent rounded-full animate-spin" />
                          )}
                          <span>Running photogrammetry analysis</span>
                        </div>
                        <div className="flex items-center gap-2">
                          {processingProgress > 60 ? (
                            <CheckCircle className="w-3 h-3 text-green-500" />
                          ) : (
                            <Clock className="w-3 h-3 text-muted-foreground" />
                          )}
                          <span>Generating 3D mesh</span>
                        </div>
                        <div className="flex items-center gap-2">
                          {processingProgress > 90 ? (
                            <CheckCircle className="w-3 h-3 text-green-500" />
                          ) : (
                            <Clock className="w-3 h-3 text-muted-foreground" />
                          )}
                          <span>Optimizing model</span>
                        </div>
                      </div>
                      <p className="text-sm text-muted-foreground">
                        Estimated time remaining: {Math.max(1, Math.round((100 - processingProgress) / 10))} minutes
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            )}
          </motion.div>

          {/* Tips & Preview Section */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="space-y-6"
          >
            {/* Photography Tips */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Camera className="h-5 w-5" />
                  Photography Tips
                </CardTitle>
                <CardDescription>
                  Follow these guidelines for best 3D reconstruction results
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  {photographyTips.map((tip, index) => (
                    <li key={index} className="flex items-start space-x-2 text-sm">
                      <div className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0" />
                      <span className="text-muted-foreground">{tip}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>

            {/* Requirements */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <AlertCircle className="h-5 w-5" />
                  Requirements
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center justify-between text-sm">
                  <span>Minimum images</span>
                  <Badge variant={selectedFiles.length >= 3 ? "default" : "destructive"}>
                    {selectedFiles.length}/3
                  </Badge>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span>Recommended images</span>
                  <Badge variant={selectedFiles.length >= 10 ? "default" : "secondary"}>
                    {selectedFiles.length}/10-20
                  </Badge>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span>File format</span>
                  <Badge variant="outline">JPG, PNG, WebP</Badge>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span>Max file size</span>
                  <Badge variant="outline">10MB each</Badge>
                </div>
              </CardContent>
            </Card>

            {/* Result Preview Placeholder */}
            <Card>
              <CardHeader>
                <CardTitle>3D Model Preview</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="aspect-square bg-gradient-to-br from-secondary to-muted rounded-xl flex items-center justify-center">
                  <div className="text-center">
                    <div className="w-24 h-24 bg-gradient-to-br from-primary/10 to-accent/10 rounded-xl mb-4 mx-auto flex items-center justify-center">
                      <ImageIcon className="h-12 w-12 text-muted-foreground" />
                    </div>
                    <p className="text-muted-foreground">
                      3D model will appear here after processing
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
