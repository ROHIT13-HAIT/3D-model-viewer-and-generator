import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { ModelViewer } from "@/components/three/model-viewer";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import {
  Sparkles,
  Download,
  Save,
  RotateCcw,
  Maximize2,
  Grid3X3,
  Zap,
} from "lucide-react";

export default function TextTo3D() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [prompt, setPrompt] = useState("");
  const [quality, setQuality] = useState("standard");
  const [style, setStyle] = useState("realistic");
  const [autoOptimize, setAutoOptimize] = useState(true);
  const [isGenerating, setIsGenerating] = useState(false);
  const [generationProgress, setGenerationProgress] = useState(0);
  const [progressText, setProgressText] = useState("");
  const [generatedModel, setGeneratedModel] = useState<any>(null);

  const generateMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest('POST', '/api/generate/text-to-3d', data);
      return response.json();
    },
    onSuccess: (data) => {
      setGeneratedModel(data.model);
      queryClient.invalidateQueries({ queryKey: ['/api/models'] });
      toast({
        title: "Generation started",
        description: "Your 3D model is being generated. This may take a few minutes.",
      });
      
      // Simulate progress updates
      const progressInterval = setInterval(() => {
        setGenerationProgress(prev => {
          const newProgress = Math.min(prev + Math.random() * 20, 95);
          
          if (newProgress < 30) {
            setProgressText("Processing prompt...");
          } else if (newProgress < 60) {
            setProgressText("Generating 3D geometry...");
          } else if (newProgress < 90) {
            setProgressText("Applying materials and textures...");
          } else {
            setProgressText("Finalizing model...");
          }
          
          return newProgress;
        });
      }, 1000);

      // Complete generation after 5 seconds
      setTimeout(() => {
        clearInterval(progressInterval);
        setGenerationProgress(100);
        setProgressText("Generation complete!");
        setIsGenerating(false);
        toast({
          title: "Model generated successfully!",
          description: "Your 3D model is ready for preview and download.",
        });
      }, 5000);
    },
    onError: (error) => {
      setIsGenerating(false);
      setGenerationProgress(0);
      toast({
        title: "Generation failed",
        description: "There was an error generating your model. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleGenerate = async () => {
    if (!user) {
      toast({
        title: "Sign in required",
        description: "Please sign in to generate 3D models.",
        variant: "destructive",
      });
      return;
    }

    if (!prompt.trim()) {
      toast({
        title: "Prompt required",
        description: "Please enter a description for your 3D model.",
        variant: "destructive",
      });
      return;
    }

    setIsGenerating(true);
    setGenerationProgress(0);
    setProgressText("Initializing generation...");

    generateMutation.mutate({
      prompt: prompt.trim(),
      userId: user.id,
      settings: {
        quality,
        style,
        autoOptimize,
      },
    });
  };

  const examplePrompts = [
    "A vintage wooden chair with carved details",
    "A modern minimalist lamp with clean lines",
    "A fantasy crystal sword with magical glow",
    "A futuristic spacecraft with sleek curves",
    "A cute cartoon dragon sitting on rocks",
  ];

  const setExamplePrompt = (examplePrompt: string) => {
    setPrompt(examplePrompt);
  };

  return (
    <div className="pt-16 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h1 className="text-4xl font-bold mb-4">
            Text to <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">3D Model</span>
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Describe your vision and watch it transform into a stunning 3D model powered by cutting-edge AI
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Input Section */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="space-y-6"
          >
            {/* Prompt Input */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Sparkles className="h-5 w-5" />
                  Describe Your Model
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="prompt">Model Description</Label>
                  <Textarea
                    id="prompt"
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    placeholder="e.g., A futuristic spacecraft with sleek curves and glowing blue accents, metallic surface with intricate details..."
                    className="min-h-[120px] mt-2"
                    data-testid="prompt-input"
                  />
                </div>
                
                {/* Prompt Examples */}
                <div>
                  <Label className="text-sm text-muted-foreground">Try these examples:</Label>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {examplePrompts.map((example, index) => (
                      <Badge
                        key={index}
                        variant="secondary"
                        className="cursor-pointer hover:bg-primary/20 transition-colors"
                        onClick={() => setExamplePrompt(example)}
                        data-testid={`example-prompt-${index}`}
                      >
                        {example.split(' ').slice(0, 3).join(' ')}...
                      </Badge>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Generation Settings */}
            <Card>
              <CardHeader>
                <CardTitle>Generation Settings</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="quality">Quality</Label>
                    <Select value={quality} onValueChange={setQuality}>
                      <SelectTrigger id="quality" data-testid="quality-select">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="fast">Fast (2-3 min)</SelectItem>
                        <SelectItem value="standard">Standard (5-7 min)</SelectItem>
                        <SelectItem value="high">High Quality (10-15 min)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="style">Style</Label>
                    <Select value={style} onValueChange={setStyle}>
                      <SelectTrigger id="style" data-testid="style-select">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="realistic">Realistic</SelectItem>
                        <SelectItem value="stylized">Stylized</SelectItem>
                        <SelectItem value="low-poly">Low Poly</SelectItem>
                        <SelectItem value="cartoon">Cartoon</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="auto-optimize"
                    checked={autoOptimize}
                    onCheckedChange={(checked) => setAutoOptimize(checked === true)}
                    data-testid="auto-optimize"
                  />
                  <Label htmlFor="auto-optimize" className="text-sm">
                    Apply automatic optimization for web use
                  </Label>
                </div>
              </CardContent>
            </Card>

            {/* Generate Button */}
            <Button
              onClick={handleGenerate}
              disabled={isGenerating || !prompt.trim()}
              className="w-full py-6 text-lg gap-2"
              data-testid="generate-button"
            >
              {isGenerating ? (
                <>
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-primary-foreground" />
                  Generating...
                </>
              ) : (
                <>
                  <Zap className="h-5 w-5" />
                  Generate 3D Model
                </>
              )}
            </Button>

            {/* Progress Indicator */}
            {isGenerating && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                transition={{ duration: 0.3 }}
              >
                <Card>
                  <CardContent className="pt-6">
                    <div className="space-y-4">
                      <div className="flex items-center justify-between text-sm">
                        <span>Generation Progress</span>
                        <span>{Math.round(generationProgress)}%</span>
                      </div>
                      <Progress value={generationProgress} className="w-full" />
                      <p className="text-sm text-muted-foreground">{progressText}</p>
                      <p className="text-xs text-muted-foreground">
                        This process may take several minutes depending on complexity and quality settings.
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            )}
          </motion.div>

          {/* Preview Section */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="space-y-6"
          >
            {/* 3D Preview */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  3D Preview
                  <div className="flex space-x-2">
                    <Button variant="outline" size="sm" data-testid="wireframe-toggle">
                      <Grid3X3 className="h-4 w-4" />
                    </Button>
                    <Button variant="outline" size="sm" data-testid="fullscreen-toggle">
                      <Maximize2 className="h-4 w-4" />
                    </Button>
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="aspect-square bg-gradient-to-br from-secondary to-muted rounded-xl overflow-hidden">
                  {generatedModel ? (
                    <ModelViewer 
                      className="w-full h-full" 
                      autoRotate={!isGenerating}
                      modelUrl={generatedModel.modelUrl}
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <div className="text-center">
                        <div className="w-24 h-24 bg-gradient-to-br from-primary/20 to-accent/20 rounded-xl mb-4 mx-auto flex items-center justify-center">
                          <Sparkles className="h-12 w-12 text-muted-foreground" />
                        </div>
                        <p className="text-muted-foreground">Your 3D model will appear here</p>
                        <p className="text-sm text-muted-foreground mt-2">
                          Enter a prompt and click generate to start
                        </p>
                      </div>
                    </div>
                  )}
                </div>

                {/* Model Controls */}
                <div className="flex justify-between items-center mt-6">
                  <div className="flex space-x-2">
                    <Button variant="outline" size="sm" data-testid="rotate-control">
                      <RotateCcw className="h-4 w-4" />
                    </Button>
                    <Button variant="outline" size="sm" data-testid="zoom-control">
                      <Maximize2 className="h-4 w-4" />
                    </Button>
                  </div>
                  
                  <div className="flex space-x-2">
                    <Button 
                      variant="outline" 
                      disabled={!generatedModel || isGenerating}
                      data-testid="save-model"
                    >
                      <Save className="h-4 w-4 mr-2" />
                      Save
                    </Button>
                    <Button 
                      disabled={!generatedModel || isGenerating}
                      data-testid="export-model"
                    >
                      <Download className="h-4 w-4 mr-2" />
                      Export
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Export Options */}
            {generatedModel && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4 }}
              >
                <Card>
                  <CardHeader>
                    <CardTitle>Export Options</CardTitle>
                    <CardDescription>
                      Download your model in various formats for different use cases
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-3 gap-3">
                      <Button variant="outline" className="flex-col h-auto py-4" data-testid="export-glb">
                        <Download className="h-5 w-5 mb-2" />
                        <span className="text-xs">GLB</span>
                        <span className="text-xs text-muted-foreground">Recommended</span>
                      </Button>
                      <Button variant="outline" className="flex-col h-auto py-4" data-testid="export-gltf">
                        <Download className="h-5 w-5 mb-2" />
                        <span className="text-xs">GLTF</span>
                        <span className="text-xs text-muted-foreground">Web compatible</span>
                      </Button>
                      <Button variant="outline" className="flex-col h-auto py-4" data-testid="export-obj">
                        <Download className="h-5 w-5 mb-2" />
                        <span className="text-xs">OBJ</span>
                        <span className="text-xs text-muted-foreground">Universal</span>
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            )}
          </motion.div>
        </div>
      </div>
    </div>
  );
}
