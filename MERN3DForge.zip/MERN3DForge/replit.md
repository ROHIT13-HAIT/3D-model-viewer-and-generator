# MERN 3D Model Generation Platform

## Overview
This is a full-stack MERN application for generating, editing, and exporting 3D models from images and text prompts. The platform uses modern web technologies including React with Vite, Node.js with Express, and PostgreSQL with Drizzle ORM. The application provides both text-to-3D and image-to-3D conversion capabilities, along with a community gallery for sharing models.

## User Preferences
Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript built using Vite for fast development and hot module replacement
- **UI Components**: shadcn/ui design system with Radix UI primitives for accessibility
- **Styling**: TailwindCSS with custom CSS variables for theming and dark/light mode support
- **Animations**: Framer Motion for smooth page transitions and component animations
- **3D Rendering**: Three.js for interactive 3D model previews and manipulation
- **State Management**: TanStack Query (React Query) for server state management and caching
- **Routing**: Wouter for lightweight client-side routing
- **Authentication**: Firebase Authentication integrated with custom auth hooks

### Backend Architecture
- **Runtime**: Node.js with Express.js framework using ESM modules
- **Language**: TypeScript for type safety across the full stack
- **API Design**: RESTful API with structured error handling and request logging middleware
- **Database ORM**: Drizzle ORM with Zod schema validation for type-safe database operations
- **Storage Layer**: Abstracted storage interface with in-memory implementation (easily replaceable with database)
- **Development Tools**: Hot reload with Vite middleware integration in development

### Database Schema
- **Users Table**: Stores user profiles linked to Firebase UIDs with email, display name, and photo URL
- **Models Table**: Stores 3D model metadata including generation type (text-to-3d/image-to-3d), processing status, and file URLs
- **Model Ratings Table**: Handles user ratings and comments for community models
- **Schema Validation**: Drizzle-Zod integration for runtime type checking and validation

### Authentication System
- **Primary Auth**: Firebase Authentication for user management and security
- **Session Management**: JWT tokens with Firebase UID verification
- **User Flow**: Automatic user creation/update on login with backend user record synchronization
- **Authorization**: Route-level protection with auth context provider

### File Management
- **Model Storage**: URLs stored in database for 3D model files (GLB/GLTF formats)
- **Thumbnails**: Automatic thumbnail generation and storage URLs
- **Upload Processing**: Support for multiple image uploads for photogrammetry pipeline

## External Dependencies

### Core Technologies
- **Database**: PostgreSQL with Neon Database serverless driver (@neondatabase/serverless)
- **Authentication**: Firebase Authentication with Google OAuth provider
- **UI Framework**: Radix UI component primitives for accessibility
- **3D Graphics**: Three.js for WebGL-based 3D rendering
- **Styling**: TailwindCSS with PostCSS for CSS processing

### Development Tools
- **Build System**: Vite with TypeScript support and React plugin
- **Database Migrations**: Drizzle Kit for schema management and migrations
- **Code Quality**: ESBuild for production builds and TypeScript compiler for type checking
- **Development**: Replit-specific plugins for error overlay and development banner

### API Integrations
- **3D Generation**: Planned integration with free open-source 3D generation APIs
- **Image Processing**: Support for photogrammetry pipeline using uploaded images
- **Model Processing**: Background processing for 3D model generation with status tracking

### Production Considerations
- **Session Storage**: connect-pg-simple for PostgreSQL session management
- **Error Handling**: Centralized error handling with status code mapping
- **Performance**: Query caching with React Query and optimized 3D model loading